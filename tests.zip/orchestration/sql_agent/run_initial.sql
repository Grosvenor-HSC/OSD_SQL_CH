/*
run_initial.sql (PURE T-SQL)
Purpose:
  Bootstrap run for initial loads by executing the Initial procs in the correct order.

How to run:
  - SQL Agent job step: Transact-SQL script (T-SQL)
  - No SQLCMD mode required

IMPORTANT:
  - Assumes the stored procs already exist in the database.
  - Deploy procs separately (or in an earlier job step).
*/

USE [DOM_LIVE];
GO
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @StartedAt datetime2(3) = SYSUTCDATETIME();
DECLARE @Summary   nvarchar(4000);

PRINT '============================================================';
PRINT 'RUN_INITIAL (PROC-DRIVEN) START | DB=DOM_LIVE';
PRINT 'Started at (UTC): ' + CONVERT(varchar(33), @StartedAt, 126);
PRINT '============================================================';

BEGIN TRY
    /* ---------------------------
       STAGE (Initial) - in order
       --------------------------- */

    /* Branch */
    PRINT '--- Branch Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_Branch_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* Employees */
    PRINT '--- Employees Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_Employees_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* EmployeeBranch */
    PRINT '--- EmployeeBranch Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_EmployeeBranch_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* EmployeeSkills */
    PRINT '--- EmployeeSkills Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_EmployeeSkills_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* EmployeeStartLeaveDates */
    PRINT '--- EmployeeStartLeaveDates Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_EmployeeStartLeaveDates_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* Clients */
    PRINT '--- Clients Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_Clients_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* Visits */
    PRINT '--- Visits Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_Visits_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* ClientDiary */
    PRINT '--- ClientDiary Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_ClientDiary_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* EmployeesDiary */
    PRINT '--- EmployeesDiary Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_EmployeesDiary_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* ClientAbsences */
    PRINT '--- ClientAbsences Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_ClientAbsences_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* EmployeesAbsences */
    PRINT '--- EmployeesAbsences Initial ---';
    SET @Summary = NULL;
    EXEC dbo.usp_Sync_EmployeesAbsences_Initial @Summary = @Summary OUTPUT;
    PRINT COALESCE(@Summary, N'(no summary returned)');

    /* ---------------------------
       CORE / REPORTING / TESTS
       (leave commented until you
        convert scripts into procs)
       --------------------------- */

    DECLARE @EndedAt datetime2(3) = SYSUTCDATETIME();
    PRINT '============================================================';
    PRINT 'RUN_INITIAL END';
    PRINT 'Ended at (UTC): ' + CONVERT(varchar(33), @EndedAt, 126);
    PRINT 'Duration (sec): ' + CAST(DATEDIFF(SECOND, @StartedAt, @EndedAt) as varchar(20));
    PRINT '============================================================';

END TRY
BEGIN CATCH
    DECLARE @Err nvarchar(2048) = ERROR_MESSAGE();
    DECLARE @Line int = ERROR_LINE();
    DECLARE @Num int = ERROR_NUMBER();
    DECLARE @State int = ERROR_STATE();
    DECLARE @Severity int = ERROR_SEVERITY();

    PRINT 'RUN_INITIAL FAILED';
    PRINT 'Error: ' + COALESCE(@Err, N'(null)');
    PRINT 'Number=' + CAST(@Num as varchar(20)) + ', Severity=' + CAST(@Severity as varchar(20)) +
          ', State=' + CAST(@State as varchar(20)) + ', Line=' + CAST(@Line as varchar(20));

    THROW;
END CATCH;
GO
